import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StarRatingComponent } from './star-rating/star-rating.component';

@NgModule({
  declarations: [StarRatingComponent],
  imports: [CommonModule],
  exports: [StarRatingComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA] // ✅ Fix: Allow web components
})
export class FeatureModule { }
