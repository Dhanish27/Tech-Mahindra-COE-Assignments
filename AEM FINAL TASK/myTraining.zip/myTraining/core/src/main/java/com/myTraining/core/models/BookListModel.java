package com.myTraining.core.models;

import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.myTraining.core.beans.BookListBean;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import com.day.cq.wcm.api.Page;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.jcr.RepositoryException;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;

import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Session;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



@Model(adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

public class BookListModel {
    private static final Logger LOGGER = LoggerFactory.getLogger(BookListModel.class);
    List<BookListBean>bookListBeansArray=null;
    @Inject
    private String bookRootPath;
    @Self
     Resource resource;


    public String getBookRootPath() {
        return bookRootPath;
    }

    @PostConstruct
    protected void init() {
        ResourceResolver resourceResolver = resource.getResourceResolver();
        Session session = resourceResolver.adaptTo(Session.class);

        QueryBuilder builder = resourceResolver.adaptTo(QueryBuilder.class);

        Map<String, String> predicate = new HashMap<>();
        predicate.put("path", bookRootPath);
        predicate.put("type", "cq:Page");

        Query query = null;
        try {
            query = builder.createQuery(PredicateGroup.create(predicate), session);
        } catch (Exception e) {
            LOGGER.error("Error in Query", e);
        }

        bookListBeansArray=new ArrayList<BookListBean>();


        SearchResult searchResult = query.getResult();

        for (Hit hit : searchResult.getHits()) {

            BookListBean bookListBean= new BookListBean();
            String path = null;
            try {
                path = hit.getPath();
                Resource bookResource = resourceResolver.getResource(path);
                Page bookPage = bookResource.adaptTo(Page.class);
                String title = bookPage.getTitle();
                String description = bookPage.getDescription();

                bookListBean.setPath(path);
                bookListBean.setDescription(description);
                bookListBean.setTitle(title);
                LOGGER.debug("Path:{} \nTitle:{} \nDescription:{}", path, title, description);
                bookListBeansArray.add(bookListBean);
            } catch (RepositoryException e) {
                throw new RuntimeException(e);
            }
        }



}
    public List<BookListBean> getBookListBean() {
        return bookListBeansArray;
    }

}
