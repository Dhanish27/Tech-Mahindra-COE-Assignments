package com.myTraining.core.services;

public interface SimpleInt {
    String getHelloWorld();
}
