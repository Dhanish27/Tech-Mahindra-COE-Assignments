package com.myTraining.core.services;

public interface CustomServiceInt {
    String getAuthorId();
    String getAuthorApi();
    String getUserName();
    String getUserPassword();
}
